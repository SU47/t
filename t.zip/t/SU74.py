# -*- coding: utf-8 -*-

import LINETCR
from LINETCR.lib.curve.ttypes import *
from datetime import datetime
import time, random, sys, ast, re, os, io, json, subprocess, threading, string, codecs, requests, ctypes, urllib, urllib2, urllib3, wikipedia, tempfile
from bs4 import BeautifulSoup
from urllib import urlopen
from io import StringIO
from threading import Thread
from gtts import gTTS
from googletrans import Translator

cl = LINETCR.LINE()
cl.login(token='Er6djmdEMLgz18iMxfe4.InGa75TRayFTfuuFrPeJ1a.r72YNRdkIjDE3ITKiHHoeoM6NtBux18JMX7JqnfcdJM=')
cl.loginResult()

ki1 = LINEVIT.LINE()
ki1.login(token="ErbZtqYRfPHBih0JiV63.GLoAPUWtFWBdZrXMVnjSiW.J/TZm+99tBEyjgsb0h59vJuSuCRAm8sC+YLgH9loPLU=")
ki1.loginResult()


print "login success"
reload(sys)
sys.setdefaultencoding('utf-8')
helpMessage ="""







"""

KAC=[cl,ki1]
mid = cl.getProfile().mid
Amid1 = ki1.getProfile().mid

wait = {
    "protectionOn":False,
}
contact = cl.getProfile()
mybackup = cl.getProfile()
mybackup.displayName = contact.displayName
mybackup.statusMessage = contact.statusMessage
mybackup.pictureStatus = contact.pictureStatus


contact = ki1.getProfile()
backup = ki1.getProfile()
backup.displayName = contact.displayName
backup.statusMessage = contact.statusMessage
backup.pictureStatus = contact.pictureStatus
#===========================================
        if op.type == 32:
            if not op.param2 in Bots:
                if wait["protectionOn"] == True: 
                    try:
                        klist=[ki1]
                        kicker = random.choice(klist) 
                        G = kicker.getGroup(op.param1)
                        kicker.kickoutFromGroup(op.param1,[op.param2])
                        kicker.inviteIntoGroup(op.param1, [op.param3])
                    except Exception, e:
                       print e
                               if op.type == 11:
            if not op.param2 in Bots:
              if wait["protectionOn"] == True:
                 try:                    
                    klist=[ki1]
                    kicker = random.choice(klist) 
                    G = kicker.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    kicker.updateGroup(G)
                    kicker.kickoutFromGroup(op.param1,[op.param2])
                    G.preventJoinByTicket = True
                    kicker.updateGroup(G)
                 except Exception, e:
                           print e
        if op.type == 13:
            G = cl.getGroup(op.param1)
            I = G.creator
            if not op.param2 in Bots:
                if wait["protectionOn"] == True:  
                    klist=[ki1]
                    kicker = random.choice(klist)
                    G = kicker.getGroup(op.param1)
                    if G is not None:
                        gInviMids = [contact.mid for contact in G.invitee]
                        kicker.cancelGroupInvitation(op.param1, gInviMids)
        if not op.param2 in Bots:
                  if wait["protectionOn"] == True:  
                   try:
                       klist=[ki1]
                       kicker = random.choice(klist)
                       G = kicker.getGroup(op.param1)
                       G.preventJoinByTicket = False
                       kicker.updateGroup(G)
                       invsend = 0
                       Ticket = kicker.reissueGroupTicket(op.param1)
                       kl1.acceptGroupInvitationByTicket(op.param1,Ticket)
                       time.sleep(0.1)
                       X = kicker.getGroup(op.param1)             
                       X.preventJoinByTicket = True
                       kl1.kickoutFromGroup(op.param1,[op.param2])
                       kicker.kickoutFromGroup(op.param1,[op.param2])
                       kl1.leaveGroup(op.param1)
                       kicker.updateGroup(X)
                   except Exception, e:
                            print e
                if not op.param2 in Bots:
                    try:
                        gs = ki1.getGroup(op.param1)
                        gs = ki2.getGroup(op.param1)
                        targets = [op.param2]
                        for target in targets:
                           try:

            elif msg.text in ["Protect:on","Protect on","เปิดป้องกัน"]:
                if wait["protectionOn"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already on\n\n"+ datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Protection On\n\n"+ datetime.today().strftime('%H:%M:%S'))
                else:
                	
            elif msg.text in ["Backup:on","Backup on","เปิด ดึงกลับ","เปิดการเชิญกลับ"]:
                if wait["Backup"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Sudah on Bos\n\n"+ datetime.today().strftime('%H:%M:%S'))
                    else:
                        cl.sendText(msg.to,"Backup On\n\n"+ datetime.today().strftime('%H:%M:%S'))
                else:
                	
                elif msg.text in ["เชคค่า","เช็คค่า","Set"]:
                print "Setting pick up..."
                md = "SELF BOT\nBy:☬ധู้さန້ণق↔ധഖาໄฟ☬\n\n"
                if wait["likeOn"] == True: md+="􀬁􀆐􏿿 ออโต้ไลค์ : ✔ 􀜁􀄯􏿿\n"
                else:md+="􀬁􀆐􏿿 ออโต้ไลค์ : ❌ 􀜁􀄰􏿿\n"
                if wait["alwayRead"] == True: md+="􀬁􀆐􏿿 อ่าน : ✔ 􀜁􀄯??\n"
                else:md+="􀬁􀆐􏿿 อ่าน : ❌ 􀜁􀄰􏿿\n"
                if wait["detectMention"] == True: md+="􀬁􀆐􏿿 ตอบแทค : ✔ 􀜁􀄯􏿿\n"
                else:md+="􀬁􀆐􏿿 ตอบแทค : ❌ 􀜁􀄰􏿿\n"
                if wait["kickMention"] == True: md+="􀬁􀆐􏿿 ออโต้เตะ: ✔ 􀜁􀄯􏿿\n"
                else:md+="􀬁􀆐􏿿 ออโต้เตะ : ❌ 􀜁􀄰􏿿\n"
                if wait["Notifed"] == True: md+="􀬁􀆐􏿿 Notifed : ✔ 􀜁􀄯􏿿\n"
                else:md+="􀬁􀆐􏿿 Notifed : ❌ 􀜁􀄰􏿿\n"
                if wait["Notifedbot"] == True: md+="􀬁􀆐􏿿 Notifedbot : ✔ 􀜁􀄯􏿿\n"
                else:md+="􀬁􀆐􏿿 Notifedbot : ❌ 􀜁􀄰􏿿\n"
                if wait["acommentOn"] == True: md+="􀬁􀆐􏿿 Hhx1 : ✔ 􀜁􀄯􏿿\n"
                else:md+="􀬁􀆐􏿿 Hhx1 : ❌ 􀜁􀄰􏿿\n"
                if wait["bcommentOn"] == True: md+="􀬁􀆐􏿿 Hhx2 : ✔ 􀜁􀄯􏿿\n"
                else:md+="􀬁􀆐􏿿 Hhx2 : ❌ 􀜁􀄰􏿿\n"
                if wait["ccommentOn"] == True: md+="􀬁􀆐􏿿 Hhx3 : ✔ 􀜁􀄯􏿿\n"
                else:md+="􀬁􀆐􏿿 Hhx3 : ❌ 􀜁􀄰􏿿\n"
                if wait["Protectcancl"] == True: md+="􀬁􀆐􏿿 Cancel : ✔ 􀜁􀄯􏿿\n"
                else:md+="􀬁􀆐􏿿 Cancel : ❌ 􀜁􀄰􏿿\n"
                if wait["winvite"] == True: md+="􀬁􀆐􏿿 เชิญ: ✔ 􀜁􀄯􏿿\n"
                else:md+="􀬁􀆐􏿿 เชิญ : ❌ 􀜁􀄰􏿿\n"
                if wait["pname"] == True: md+="􀬁􀆐􏿿 ล็อคชื่อ : ✔ 􀜁􀄯􏿿\n"
                else:md+="􀬁􀆐􏿿 ล็อคชื่อ : ❌ 􀜁􀄰􏿿\n"
                if wait["contact"] == True: md+="􀬁􀆐􏿿 Contact : ✔ 􀜁􀄯􏿿\n"
                else: md+="􀬁􀆐􏿿 Contact : ❌ 􀜁􀄰􏿿\n"
                if wait["autoJoin"] == True: md+="􀬁􀆐􏿿 ออโต้เข้ากลุ่ม : ✔ 􀜁􀄯􏿿\n"
                else: md +="􀬁􀆐􏿿 ออโต้เข้ากลุ่ม : ❌ 􀜁􀄰􏿿\n"
                if wait["autoCancel"]["on"] == True:md+="􀬁􀆐􏿿 Group cancel :" + str(wait["autoCancel"]["members"]) + " 􀜁􀄯􏿿\n"
                else: md+= "􀬁􀆐􏿿 Group cancel : ❌ 􀜁􀄰􏿿\n"
                if wait["leaveRoom"] == True: md+="􀬁􀆐􏿿 ออโต้ ออกแชท : ✔ 􀜁􀄯􏿿\n"
                else: md+="􀬁􀆐􏿿 ออโต้ ออกแชท: ❌ 􀜁􀄰􏿿\n"
                if wait["timeline"] == True: md+="􀬁􀆐􏿿 ออโต้ แชร์ : ✔ 􀜁􀄯􏿿\n"
                else:md+="􀬁􀆐􏿿 ออโต้ แชร์ : ❌ 􀜁􀄰􏿿\n"
                if wait["clock"] == True: md+="􀬁􀆐􏿿 ชื่อ นาฬิกา : ✔ 􀜁􀄯􏿿\n"
                else:md+="􀬁􀆐􏿿 ชื่อ นาฬิกา : ❌ 􀜁􀄰􏿿\n"
                if wait["autoAdd"] == True: md+="􀬁􀆐􏿿 ออโต้ เพิ่มเพื่อน : ✔ 􀜁􀄯􏿿\n"
                else:md+="􀬁􀆐􏿿 ออโต้ เพิ่มเพื่อน : ❌ 􀜁􀄰􏿿\n"
                if wait["commentOn"] == True: md+="􀬁􀆐􏿿 ออโต้ คอมเม้น : ✔ 􀜁􀄯􏿿\n"
                else:md+="􀬁􀆐􏿿 ออโต้ คอมเม้น : ❌ 􀜁􀄰􏿿\n"
                if wait["Backup"] == True: md+="􀬁􀆐􏿿 ดึงกลับ : ✔ 􀜁􀄯􏿿\n"
                else:md+="􀬁􀆐􏿿 ดึงกลับ : ❌ 􀜁􀄰􏿿\n"
                if wait["qr"] == True: md+="􀬁􀆐􏿿 ป้องกัน QR : ✔ 􀜁􀄯􏿿\n"
                else:md+="􀬁􀆐􏿿 ป้องกัน QR : ❌ 􀜁􀄰􏿿\n"
                cl.sendText(msg.to,md)
                msg.contentType = 13
                msg.contentMetadata = {'mid': admsa}
                cl.sendMessage(msg)